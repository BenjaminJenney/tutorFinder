// Lambda Function code for Alexa.
// Paste this into your index.js file. 

const Alexa = require("ask-sdk");
const https = require("https");

let tutorName = '';
let classCode ='';
let number = '';
let startDate = '';
let endDate = '';
let startTime = '';
let endTime = '';
let days = [];

const invocationName = "create tutor appointment";

// Session Attributes 
//   Alexa will track attributes for you, by default only during the lifespan of your session.
//   The history[] array will track previous request(s), used for contextual Help/Yes/No handling.
//   Set up DynamoDB persistence to have the skill save and reload these attributes between skill sessions.

function getMemoryAttributes() {   const memoryAttributes = {
       "history":[],

        // The remaining attributes will be useful after DynamoDB persistence is configured
       "launchCount":0,
       "lastUseTimestamp":0,

       "lastSpeechOutput":{},
       "nextIntent":[]

       // "favoriteColor":"",
       // "name":"",
       // "namePronounce":"",
       // "email":"",
       // "mobileNumber":"",
       // "city":"",
       // "state":"",
       // "postcode":"",
       // "birthday":"",
       // "bookmark":0,
       // "wishlist":[],
   };
   return memoryAttributes;
};

const maxHistorySize = 20; // remember only latest 20 intents 


// 1. Intent Handlers =============================================

const AMAZON_FallbackIntent_Handler =  {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.FallbackIntent' ;
    },
    handle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        const responseBuilder = handlerInput.responseBuilder;
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();

        let previousSpeech = getPreviousSpeechOutput(sessionAttributes);

        return responseBuilder
            .speak('Sorry I didnt catch what you said, ' + stripSpeak(previousSpeech.outputSpeech))
            .reprompt(stripSpeak(previousSpeech.reprompt))
            .getResponse();
    },
};

const AMAZON_CancelIntent_Handler =  {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.CancelIntent' ;
    },
    handle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        const responseBuilder = handlerInput.responseBuilder;
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();


        let say = 'Okay, talk to you later! ';

        return responseBuilder
            .speak(say)
            .withShouldEndSession(true)
            .getResponse();
    },
};

const AMAZON_HelpIntent_Handler =  {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.HelpIntent' ;
    },
    handle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        const responseBuilder = handlerInput.responseBuilder;
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();

        let intents = getCustomIntents();
        let sampleIntent = randomElement(intents);

        let say = 'You asked for help. '; 

        // let previousIntent = getPreviousIntent(sessionAttributes);
        // if (previousIntent && !handlerInput.requestEnvelope.session.new) {
        //     say += 'Your last intent was ' + previousIntent + '. ';
        // }
        // say +=  'I understand  ' + intents.length + ' intents, '

        say += ' Here something you can ask me, ' + getSampleUtterance(sampleIntent);

        return responseBuilder
            .speak(say)
            .reprompt('try again, ' + say)
            .getResponse();
    },
};

const AMAZON_StopIntent_Handler =  {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.StopIntent' ;
    },
    handle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        const responseBuilder = handlerInput.responseBuilder;
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();


        let say = 'Okay, talk to you later! ';

        return responseBuilder
            .speak(say)
            .withShouldEndSession(true)
            .getResponse();
    },
};

const AMAZON_NavigateHomeIntent_Handler =  {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' && request.intent.name === 'AMAZON.NavigateHomeIntent' ;
    },
    handle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        const responseBuilder = handlerInput.responseBuilder;
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();

        let say = 'Hello from AMAZON.NavigateHomeIntent. ';


        return responseBuilder
            .speak(say)
            .reprompt('try again, ' + say)
            .getResponse();
    },
};

const GetAppointment_Handler =  {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' && request.intent.name === 'GetAppointment' ;
    },
    handle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        const responseBuilder = handlerInput.responseBuilder;
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();

        // delegate to Alexa to collect all the required slots 
        const currentIntent = request.intent; 
        if (request.dialogState && request.dialogState !== 'COMPLETED') { 
            return handlerInput.responseBuilder
                .addDelegateDirective(currentIntent)
                .getResponse();

        } 
        let say = 'Hello from GetAppointment. ';
        const slots = handlerInput.requestEnvelope.request.intent.slots;
        let slotStatus = '';
        let resolvedSlot;
        
        let slotValues = getSlotValues(request.intent.slots); 
        // getSlotValues returns .heardAs, .resolved, and .isValidated for each slot, according to request slot status codes ER_SUCCESS_MATCH, ER_SUCCESS_NO_MATCH, or traditional simple request slot without resolutions

        // console.log('***** slotValues: ' +  JSON.stringify(slotValues, null, 2));
        //   SLOT: tutorName 
        if (slotValues.tutorName.heardAs) {
            slotStatus += ' slot tutorName was heard as ' + slotValues.tutorName.heardAs + '. ';
        } else {
            slotStatus += 'slot tutorName is empty. ';
        }
        if (slotValues.tutorName.ERstatus === 'ER_SUCCESS_MATCH') {
            slotStatus += 'a valid ';
            if(slotValues.tutorName.resolved !== slotValues.tutorName.heardAs) {
                slotStatus += 'synonym for ' + slotValues.tutorName.resolved + '. '; 
                } else {
                slotStatus += 'match. '
            } // else {
                //
        }
        if (slotValues.tutorName.ERstatus === 'ER_SUCCESS_NO_MATCH') {
            slotStatus += 'which did not match any slot value. ';
            console.log('***** consider adding "' + slotValues.tutorName.heardAs + '" to the custom slot type used by slot tutorName! '); 
        }

        if( (slotValues.tutorName.ERstatus === 'ER_SUCCESS_NO_MATCH') ||  (!slotValues.tutorName.heardAs) ) {
            slotStatus += 'A few valid values are, ' + sayArray(getExampleSlotValues('GetAppointment','tutorName'), 'or');
        }
        
        tutorName = slots.tutorName;
        
        //   SLOT: startDate 
        if (slotValues.startDate.heardAs) {
            slotStatus += ' slot startDate was heard as ' + slotValues.startDate.heardAs + '. ';
        } else {
            slotStatus += 'slot startDate is empty. ';
        }
        if (slotValues.startDate.ERstatus === 'ER_SUCCESS_MATCH') {
            slotStatus += 'a valid ';
            if(slotValues.startDate.resolved !== slotValues.startDate.heardAs) {
                slotStatus += 'synonym for ' + slotValues.startDate.resolved + '. '; 
                } else {
                slotStatus += 'match. '
            } // else {
                //
        }
        if (slotValues.startDate.ERstatus === 'ER_SUCCESS_NO_MATCH') {
            slotStatus += 'which did not match any slot value. ';
            console.log('***** consider adding "' + slotValues.startDate.heardAs + '" to the custom slot type used by slot startDate! '); 
        }

        if( (slotValues.startDate.ERstatus === 'ER_SUCCESS_NO_MATCH') ||  (!slotValues.startDate.heardAs) ) {
            slotStatus += 'A few valid values are, ' + sayArray(getExampleSlotValues('GetAppointment','startDate'), 'or');
        }
        startDate = slots.startDate.value;
        //   SLOT: endDate 
        if (slotValues.endDate.heardAs) {
            slotStatus += ' slot endDate was heard as ' + slotValues.endDate.heardAs + '. ';
        } else {
            slotStatus += 'slot endDate is empty. ';
        }
        if (slotValues.endDate.ERstatus === 'ER_SUCCESS_MATCH') {
            slotStatus += 'a valid ';
            if(slotValues.endDate.resolved !== slotValues.endDate.heardAs) {
                slotStatus += 'synonym for ' + slotValues.endDate.resolved + '. '; 
                } else {
                slotStatus += 'match. '
            } // else {
                //
        }
        if (slotValues.endDate.ERstatus === 'ER_SUCCESS_NO_MATCH') {
            slotStatus += 'which did not match any slot value. ';
            console.log('***** consider adding "' + slotValues.endDate.heardAs + '" to the custom slot type used by slot endDate! '); 
        }

        if( (slotValues.endDate.ERstatus === 'ER_SUCCESS_NO_MATCH') ||  (!slotValues.endDate.heardAs) ) {
            slotStatus += 'A few valid values are, ' + sayArray(getExampleSlotValues('GetAppointment','endDate'), 'or');
        }
        
        endDate = slots.endDate.value;
        
        //   SLOT: startTime 
        if (slotValues.startTime.heardAs) {
            slotStatus += ' slot startTime was heard as ' + slotValues.startTime.heardAs + '. ';
        } else {
            slotStatus += 'slot startTime is empty. ';
        }
        if (slotValues.startTime.ERstatus === 'ER_SUCCESS_MATCH') {
            slotStatus += 'a valid ';
            if(slotValues.startTime.resolved !== slotValues.startTime.heardAs) {
                slotStatus += 'synonym for ' + slotValues.startTime.resolved + '. '; 
                } else {
                slotStatus += 'match. '
            } // else {
                //
        }
        if (slotValues.startTime.ERstatus === 'ER_SUCCESS_NO_MATCH') {
            slotStatus += 'which did not match any slot value. ';
            console.log('***** consider adding "' + slotValues.startTime.heardAs + '" to the custom slot type used by slot startTime! '); 
        }

        if( (slotValues.startTime.ERstatus === 'ER_SUCCESS_NO_MATCH') ||  (!slotValues.startTime.heardAs) ) {
            slotStatus += 'A few valid values are, ' + sayArray(getExampleSlotValues('GetAppointment','startTime'), 'or');
        }
        startTime = slots.startTime.value;
        //   SLOT: endTime 
        if (slotValues.endTime.heardAs) {
            slotStatus += ' slot endTime was heard as ' + slotValues.endTime.heardAs + '. ';
        } else {
            slotStatus += 'slot endTime is empty. ';
        }
        if (slotValues.endTime.ERstatus === 'ER_SUCCESS_MATCH') {
            slotStatus += 'a valid ';
            if(slotValues.endTime.resolved !== slotValues.endTime.heardAs) {
                slotStatus += 'synonym for ' + slotValues.endTime.resolved + '. '; 
                } else {
                slotStatus += 'match. '
            } // else {
                //
        }
        if (slotValues.endTime.ERstatus === 'ER_SUCCESS_NO_MATCH') {
            slotStatus += 'which did not match any slot value. ';
            console.log('***** consider adding "' + slotValues.endTime.heardAs + '" to the custom slot type used by slot endTime! '); 
        }

        if( (slotValues.endTime.ERstatus === 'ER_SUCCESS_NO_MATCH') ||  (!slotValues.endTime.heardAs) ) {
            slotStatus += 'A few valid values are, ' + sayArray(getExampleSlotValues('GetAppointment','endTime'), 'or');
        }
        
        endTime = slots.endTime.value;
        
        //   SLOT: classCode 
        if (slotValues.classCode.heardAs) {
            slotStatus += ' slot classCode was heard as ' + slotValues.classCode.heardAs + '. ';
        } else {
            slotStatus += 'slot classCode is empty. ';
        }
        if (slotValues.classCode.ERstatus === 'ER_SUCCESS_MATCH') {
            slotStatus += 'a valid ';
            if(slotValues.classCode.resolved !== slotValues.classCode.heardAs) {
                slotStatus += 'synonym for ' + slotValues.classCode.resolved + '. '; 
                } else {
                slotStatus += 'match. '
            } // else {
                //
        }
        if (slotValues.classCode.ERstatus === 'ER_SUCCESS_NO_MATCH') {
            slotStatus += 'which did not match any slot value. ';
            console.log('***** consider adding "' + slotValues.classCode.heardAs + '" to the custom slot type used by slot classCode! '); 
        }

        if( (slotValues.classCode.ERstatus === 'ER_SUCCESS_NO_MATCH') ||  (!slotValues.classCode.heardAs) ) {
            slotStatus += 'A few valid values are, ' + sayArray(getExampleSlotValues('GetAppointment','classCode'), 'or');
        }
        
        classCode = slots.classCode.value;
        
        //   SLOT: number 
        if (slotValues.number.heardAs) {
            slotStatus += ' slot number was heard as ' + slotValues.number.heardAs + '. ';
        } else {
            slotStatus += 'slot number is empty. ';
        }
        if (slotValues.number.ERstatus === 'ER_SUCCESS_MATCH') {
            slotStatus += 'a valid ';
            if(slotValues.number.resolved !== slotValues.number.heardAs) {
                slotStatus += 'synonym for ' + slotValues.number.resolved + '. '; 
                } else {
                slotStatus += 'match. '
            } // else {
                //
        }
        if (slotValues.number.ERstatus === 'ER_SUCCESS_NO_MATCH') {
            slotStatus += 'which did not match any slot value. ';
            console.log('***** consider adding "' + slotValues.number.heardAs + '" to the custom slot type used by slot number! '); 
        }

        if( (slotValues.number.ERstatus === 'ER_SUCCESS_NO_MATCH') ||  (!slotValues.number.heardAs) ) {
            slotStatus += 'A few valid values are, ' + sayArray(getExampleSlotValues('GetAppointment','number'), 'or');
        }
        
        number = slots.number.value;

        say += slotStatus;
        

        return responseBuilder
            .speak(say)
            .reprompt('try again, ' + say)
            .getResponse();
    },
};

const GetDays_Handler =  {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' && request.intent.name === 'GetDays' ;
    },
    handle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        const responseBuilder = handlerInput.responseBuilder;
        const slots = handlerInput.requestEnvelope.request.intent.slots;
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();

        let say = 'Hello from GetDays. ';

        let slotStatus = '';
        let resolvedSlot;

        let slotValues = getSlotValues(request.intent.slots); 
        // getSlotValues returns .heardAs, .resolved, and .isValidated for each slot, according to request slot status codes ER_SUCCESS_MATCH, ER_SUCCESS_NO_MATCH, or traditional simple request slot without resolutions

        // console.log('***** slotValues: ' +  JSON.stringify(slotValues, null, 2));
        //   SLOT: dayOne 
        if (slotValues.dayOne.heardAs) {
            slotStatus += ' slot dayOne was heard as ' + slotValues.dayOne.heardAs + '. ';
        } else {
            slotStatus += 'slot dayOne is empty. ';
        }
        if (slotValues.dayOne.ERstatus === 'ER_SUCCESS_MATCH') {
            slotStatus += 'a valid ';
            if(slotValues.dayOne.resolved !== slotValues.dayOne.heardAs) {
                slotStatus += 'synonym for ' + slotValues.dayOne.resolved + '. '; 
                } else {
                slotStatus += 'match. '
            } // else {
                //
        }
        if (slotValues.dayOne.ERstatus === 'ER_SUCCESS_NO_MATCH') {
            slotStatus += 'which did not match any slot value. ';
            console.log('***** consider adding "' + slotValues.dayOne.heardAs + '" to the custom slot type used by slot dayOne! '); 
        }

        if( (slotValues.dayOne.ERstatus === 'ER_SUCCESS_NO_MATCH') ||  (!slotValues.dayOne.heardAs) ) {
            slotStatus += 'A few valid values are, ' + sayArray(getExampleSlotValues('GetDays','dayOne'), 'or');
        }
        days.push(slots.dayOne.value);
        //   SLOT: dayTwo 
        if (slotValues.dayTwo.heardAs) {
            slotStatus += ' slot dayTwo was heard as ' + slotValues.dayTwo.heardAs + '. ';
        } else {
            slotStatus += 'slot dayTwo is empty. ';
        }
        if (slotValues.dayTwo.ERstatus === 'ER_SUCCESS_MATCH') {
            slotStatus += 'a valid ';
            if(slotValues.dayTwo.resolved !== slotValues.dayTwo.heardAs) {
                slotStatus += 'synonym for ' + slotValues.dayTwo.resolved + '. '; 
                } else {
                slotStatus += 'match. '
            } // else {
                //
        }
        if (slotValues.dayTwo.ERstatus === 'ER_SUCCESS_NO_MATCH') {
            slotStatus += 'which did not match any slot value. ';
            console.log('***** consider adding "' + slotValues.dayTwo.heardAs + '" to the custom slot type used by slot dayTwo! '); 
        }

        if( (slotValues.dayTwo.ERstatus === 'ER_SUCCESS_NO_MATCH') ||  (!slotValues.dayTwo.heardAs) ) {
            slotStatus += 'A few valid values are, ' + sayArray(getExampleSlotValues('GetDays','dayTwo'), 'or');
        }
        
        days.push(slots.dayTwo.value);
        //   SLOT: dayThree 
        if (slotValues.dayThree.heardAs) {
            slotStatus += ' slot dayThree was heard as ' + slotValues.dayThree.heardAs + '. ';
        } else {
            slotStatus += 'slot dayThree is empty. ';
        }
        if (slotValues.dayThree.ERstatus === 'ER_SUCCESS_MATCH') {
            slotStatus += 'a valid ';
            if(slotValues.dayThree.resolved !== slotValues.dayThree.heardAs) {
                slotStatus += 'synonym for ' + slotValues.dayThree.resolved + '. '; 
                } else {
                slotStatus += 'match. '
            } // else {
                //
        }
        if (slotValues.dayThree.ERstatus === 'ER_SUCCESS_NO_MATCH') {
            slotStatus += 'which did not match any slot value. ';
            console.log('***** consider adding "' + slotValues.dayThree.heardAs + '" to the custom slot type used by slot dayThree! '); 
        }

        if( (slotValues.dayThree.ERstatus === 'ER_SUCCESS_NO_MATCH') ||  (!slotValues.dayThree.heardAs) ) {
            slotStatus += 'A few valid values are, ' + sayArray(getExampleSlotValues('GetDays','dayThree'), 'or');
        }
        
        days.push(slots.dayThree.value);
        
        say += slotStatus;


        return responseBuilder
            .speak(say)
            .reprompt('try again, ' + say)
            .getResponse();
    },
};

const PostAppointment_Handler =  {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'IntentRequest' && request.intent.name === 'PostAppointment' ;
    },
    handle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        const responseBuilder = handlerInput.responseBuilder;
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();

        let say = 'Hello from PostAppointment. ';

        let post_req  = null,
        post_data = JSON.stringify({"classCode": classCode,"startDate": startDate,"endDate": endDate,"startTime": startTime,"endTime": endTime,"tutorName":tutorName,"days": days, "__v":0});
        let post_options = {
            hostname: 'wnv9dbdah5.execute-api.us-east-1.amazonaws.com',//url without https://
            port    : '443',
            path    : '/dev/notes/',
            method  : 'POST',
            headers : {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache',
                'Content-Length': post_data.length
            }
        };
        
        post_req = https.request(post_options, function (res) {
            console.log('STATUS: ' + res.statusCode);
            console.log('HEADERS: ' + JSON.stringify(res.headers));
            res.setEncoding('utf8');
            res.on('data', function (chunk) {
                console.log('Response: ', chunk);
            });
        });
        
        post_req.on('error', function(e) {
            console.log('problem with request: ' + e.message);
        });
        post_req.write(post_data);
        post_req.end();

        return responseBuilder
            .speak(say)
            .reprompt('try again, ' + say)
            .getResponse();
    },
};

const LaunchRequest_Handler =  {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'LaunchRequest';
    },
    handle(handlerInput) {
        const responseBuilder = handlerInput.responseBuilder;

        let say = 'hello' + ' and welcome to ' + invocationName + ' ! Say help to hear some options.';

        let skillTitle = capitalize(invocationName);


        return responseBuilder
            .speak(say)
            .reprompt('try again, ' + say)
            .withStandardCard('Welcome!', 
              'Hello!\nThis is a card for your skill, ' + skillTitle,
               welcomeCardImg.smallImageUrl, welcomeCardImg.largeImageUrl)
            .getResponse();
    },
};

const SessionEndedHandler =  {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;
        return request.type === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);
        return handlerInput.responseBuilder.getResponse();
    }
};

const ErrorHandler =  {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const request = handlerInput.requestEnvelope.request;

        console.log(`Error handled: ${error.message}`);
        // console.log(`Original Request was: ${JSON.stringify(request, null, 2)}`);

        return handlerInput.responseBuilder
            .speak('Sorry, an error occurred.  Please say again.')
            .reprompt('Sorry, an error occurred.  Please say again.')
            .getResponse();
    }
};


// 2. Constants ===========================================================================

    // Here you can define static data, to be used elsewhere in your code.  For example: 
    //    const myString = "Hello World";
    //    const myArray  = [ "orange", "grape", "strawberry" ];
    //    const myObject = { "city": "Boston",  "state":"Massachusetts" };

const APP_ID = undefined;  // TODO replace with your Skill ID (OPTIONAL).

// 3.  Helper Functions ===================================================================

function capitalize(myString) {

     return myString.replace(/(?:^|\s)\S/g, function(a) { return a.toUpperCase(); }) ;
}

 
function randomElement(myArray) { 
    return(myArray[Math.floor(Math.random() * myArray.length)]); 
} 
 
function stripSpeak(str) { 
    return(str.replace('<speak>', '').replace('</speak>', '')); 
} 
 
 
 
 
function getSlotValues(filledSlots) { 
    const slotValues = {}; 
 
    Object.keys(filledSlots).forEach((item) => { 
        const name  = filledSlots[item].name; 
 
        if (filledSlots[item] && 
            filledSlots[item].resolutions && 
            filledSlots[item].resolutions.resolutionsPerAuthority[0] && 
            filledSlots[item].resolutions.resolutionsPerAuthority[0].status && 
            filledSlots[item].resolutions.resolutionsPerAuthority[0].status.code) { 
            switch (filledSlots[item].resolutions.resolutionsPerAuthority[0].status.code) { 
                case 'ER_SUCCESS_MATCH': 
                    slotValues[name] = { 
                        heardAs: filledSlots[item].value, 
                        resolved: filledSlots[item].resolutions.resolutionsPerAuthority[0].values[0].value.name, 
                        ERstatus: 'ER_SUCCESS_MATCH' 
                    }; 
                    break; 
                case 'ER_SUCCESS_NO_MATCH': 
                    slotValues[name] = { 
                        heardAs: filledSlots[item].value, 
                        resolved: '', 
                        ERstatus: 'ER_SUCCESS_NO_MATCH' 
                    }; 
                    break; 
                default: 
                    break; 
            } 
        } else { 
            slotValues[name] = { 
                heardAs: filledSlots[item].value, 
                resolved: '', 
                ERstatus: '' 
            }; 
        } 
    }, this); 
 
    return slotValues; 
} 
 
function getExampleSlotValues(intentName, slotName) { 
 
    let examples = []; 
    let slotType = ''; 
    let slotValuesFull = []; 
 
    let intents = model.interactionModel.languageModel.intents; 
    for (let i = 0; i < intents.length; i++) { 
        if (intents[i].name == intentName) { 
            let slots = intents[i].slots; 
            for (let j = 0; j < slots.length; j++) { 
                if (slots[j].name === slotName) { 
                    slotType = slots[j].type; 
 
                } 
            } 
        } 
         
    } 
    let types = model.interactionModel.languageModel.types; 
    for (let i = 0; i < types.length; i++) { 
        if (types[i].name === slotType) { 
            slotValuesFull = types[i].values; 
        } 
    } 
 
 
    examples.push(slotValuesFull[0].name.value); 
    examples.push(slotValuesFull[1].name.value); 
    if (slotValuesFull.length > 2) { 
        examples.push(slotValuesFull[2].name.value); 
    } 
 
 
    return examples; 
} 
 
function sayArray(myData, penultimateWord = 'and') { 
    let result = ''; 
 
    myData.forEach(function(element, index, arr) { 
 
        if (index === 0) { 
            result = element; 
        } else if (index === myData.length - 1) { 
            result += ` ${penultimateWord} ${element}`; 
        } else { 
            result += `, ${element}`; 
        } 
    }); 
    return result; 
} 
function supportsDisplay(handlerInput) // returns true if the skill is running on a device with a display (Echo Show, Echo Spot, etc.) 
{                                      //  Enable your skill for display as shown here: https://alexa.design/enabledisplay 
    const hasDisplay = 
        handlerInput.requestEnvelope.context && 
        handlerInput.requestEnvelope.context.System && 
        handlerInput.requestEnvelope.context.System.device && 
        handlerInput.requestEnvelope.context.System.device.supportedInterfaces && 
        handlerInput.requestEnvelope.context.System.device.supportedInterfaces.Display; 
 
    return hasDisplay; 
} 
 
 
const welcomeCardImg = { 
    smallImageUrl: "https://s3.amazonaws.com/skill-images-789/cards/card_plane720_480.png", 
    largeImageUrl: "https://s3.amazonaws.com/skill-images-789/cards/card_plane1200_800.png" 
 
 
}; 
 
const DisplayImg1 = { 
    title: 'Jet Plane', 
    url: 'https://s3.amazonaws.com/skill-images-789/display/plane340_340.png' 
}; 
const DisplayImg2 = { 
    title: 'Starry Sky', 
    url: 'https://s3.amazonaws.com/skill-images-789/display/background1024_600.png' 
 
}; 
 
function getCustomIntents() { 
    const modelIntents = model.interactionModel.languageModel.intents; 
 
    let customIntents = []; 
 
 
    for (let i = 0; i < modelIntents.length; i++) { 
 
        if(modelIntents[i].name.substring(0,7) != "AMAZON." && modelIntents[i].name !== "LaunchRequest" ) { 
            customIntents.push(modelIntents[i]); 
        } 
    } 
    return customIntents; 
} 
 
function getSampleUtterance(intent) { 
 
    return randomElement(intent.samples); 
 
} 
 
function getPreviousIntent(attrs) { 
 
    if (attrs.history && attrs.history.length > 1) { 
        return attrs.history[attrs.history.length - 2].IntentRequest; 
 
    } else { 
        return false; 
    } 
 
} 
 
function getPreviousSpeechOutput(attrs) { 
 
    if (attrs.lastSpeechOutput && attrs.history.length > 1) { 
        return attrs.lastSpeechOutput; 
 
    } else { 
        return false; 
    } 
 
} 
 
function timeDelta(t1, t2) { 
 
    const dt1 = new Date(t1); 
    const dt2 = new Date(t2); 
    const timeSpanMS = dt2.getTime() - dt1.getTime(); 
    const span = { 
        "timeSpanMIN": Math.floor(timeSpanMS / (1000 * 60 )), 
        "timeSpanHR": Math.floor(timeSpanMS / (1000 * 60 * 60)), 
        "timeSpanDAY": Math.floor(timeSpanMS / (1000 * 60 * 60 * 24)), 
        "timeSpanDesc" : "" 
    }; 
 
 
    if (span.timeSpanHR < 2) { 
        span.timeSpanDesc = span.timeSpanMIN + " minutes"; 
    } else if (span.timeSpanDAY < 2) { 
        span.timeSpanDesc = span.timeSpanHR + " hours"; 
    } else { 
        span.timeSpanDesc = span.timeSpanDAY + " days"; 
    } 
 
 
    return span; 
 
} 
 
 
const InitMemoryAttributesInterceptor = { 
    process(handlerInput) { 
        let sessionAttributes = {}; 
        if(handlerInput.requestEnvelope.session['new']) { 
 
            sessionAttributes = handlerInput.attributesManager.getSessionAttributes(); 
 
            let memoryAttributes = getMemoryAttributes(); 
 
            if(Object.keys(sessionAttributes).length === 0) { 
 
                Object.keys(memoryAttributes).forEach(function(key) {  // initialize all attributes from global list 
 
                    sessionAttributes[key] = memoryAttributes[key]; 
 
                }); 
 
            } 
            handlerInput.attributesManager.setSessionAttributes(sessionAttributes); 
 
 
        } 
    } 
}; 
 
const RequestHistoryInterceptor = { 
    process(handlerInput) { 
 
        const thisRequest = handlerInput.requestEnvelope.request; 
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes(); 
 
        let history = sessionAttributes['history'] || []; 
 
        let IntentRequest = {}; 
        if (thisRequest.type === 'IntentRequest' ) { 
 
            let slots = []; 
 
            IntentRequest = { 
                'IntentRequest' : thisRequest.intent.name 
            }; 
 
            if (thisRequest.intent.slots) { 
 
                for (let slot in thisRequest.intent.slots) { 
                    let slotObj = {}; 
                    slotObj[slot] = thisRequest.intent.slots[slot].value; 
                    slots.push(slotObj); 
                } 
 
                IntentRequest = { 
                    'IntentRequest' : thisRequest.intent.name, 
                    'slots' : slots 
                }; 
 
            } 
 
        } else { 
            IntentRequest = {'IntentRequest' : thisRequest.type}; 
        } 
        if(history.length > maxHistorySize - 1) { 
            history.shift(); 
        } 
        history.push(IntentRequest); 
 
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes); 
 
    } 
 
}; 
 
 
 
 
const RequestPersistenceInterceptor = { 
    process(handlerInput) { 
 
        if(handlerInput.requestEnvelope.session['new']) { 
 
            return new Promise((resolve, reject) => { 
 
                handlerInput.attributesManager.getPersistentAttributes() 
 
                    .then((sessionAttributes) => { 
                        sessionAttributes = sessionAttributes || {}; 
 
 
                        sessionAttributes['launchCount'] += 1; 
 
                        handlerInput.attributesManager.setSessionAttributes(sessionAttributes); 
 
                        handlerInput.attributesManager.savePersistentAttributes() 
                            .then(() => { 
                                resolve(); 
                            }) 
                            .catch((err) => { 
                                reject(err); 
                            }); 
                    }); 
 
            }); 
 
        } 
    } 
}; 
 
 
const ResponseRecordSpeechOutputInterceptor = { 
    process(handlerInput, responseOutput) { 
 
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes(); 
        let lastSpeechOutput = { 
            "outputSpeech":responseOutput.outputSpeech.ssml, 
            "reprompt":responseOutput.reprompt.outputSpeech.ssml 
        }; 
 
        sessionAttributes['lastSpeechOutput'] = lastSpeechOutput; 
 
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes); 
 
    } 
}; 
 
const ResponsePersistenceInterceptor = { 
    process(handlerInput, responseOutput) { 
 
        const ses = (typeof responseOutput.shouldEndSession == "undefined" ? true : responseOutput.shouldEndSession); 
 
        if(ses || handlerInput.requestEnvelope.request.type == 'SessionEndedRequest') { // skill was stopped or timed out 
 
            let sessionAttributes = handlerInput.attributesManager.getSessionAttributes(); 
 
            sessionAttributes['lastUseTimestamp'] = new Date(handlerInput.requestEnvelope.request.timestamp).getTime(); 
 
            handlerInput.attributesManager.setPersistentAttributes(sessionAttributes); 
 
            return new Promise((resolve, reject) => { 
                handlerInput.attributesManager.savePersistentAttributes() 
                    .then(() => { 
                        resolve(); 
                    }) 
                    .catch((err) => { 
                        reject(err); 
                    }); 
 
            }); 
 
        } 
 
    } 
}; 
 
 
 
// 4. Exports handler function and setup ===================================================
const skillBuilder = Alexa.SkillBuilders.standard();
exports.handler = skillBuilder
    .addRequestHandlers(
        AMAZON_FallbackIntent_Handler, 
        AMAZON_CancelIntent_Handler, 
        AMAZON_HelpIntent_Handler, 
        AMAZON_StopIntent_Handler, 
        AMAZON_NavigateHomeIntent_Handler, 
        GetAppointment_Handler, 
        GetDays_Handler, 
        PostAppointment_Handler, 
        LaunchRequest_Handler, 
        SessionEndedHandler
    )
    .addErrorHandlers(ErrorHandler)
    .addRequestInterceptors(InitMemoryAttributesInterceptor)
    .addRequestInterceptors(RequestHistoryInterceptor)

    .lambda();


// End of Skill code -------------------------------------------------------------
// Static Language Model for reference

const model = {
  "interactionModel": {
    "languageModel": {
      "invocationName": "create tutor appointment",
      "intents": [
        {
          "name": "AMAZON.FallbackIntent",
          "samples": []
        },
        {
          "name": "AMAZON.CancelIntent",
          "samples": []
        },
        {
          "name": "AMAZON.HelpIntent",
          "samples": []
        },
        {
          "name": "AMAZON.StopIntent",
          "samples": []
        },
        {
          "name": "AMAZON.NavigateHomeIntent",
          "samples": []
        },
        {
          "name": "GetAppointment",
          "slots": [
            {
              "name": "tutorName",
              "type": "AMAZON.Person",
              "samples": [
                "{tutorName}"
              ]
            },
            {
              "name": "startDate",
              "type": "AMAZON.DATE",
              "samples": [
                "{startDate}"
              ]
            },
            {
              "name": "endDate",
              "type": "AMAZON.DATE",
              "samples": [
                "{endDate}"
              ]
            },
            {
              "name": "startTime",
              "type": "AMAZON.TIME",
              "samples": [
                "{startTime}"
              ]
            },
            {
              "name": "endTime",
              "type": "AMAZON.TIME",
              "samples": [
                "{endTime}"
              ]
            },
            {
              "name": "classCode",
              "type": "ClassCode",
              "samples": [
                "{classCode}"
              ]
            },
            {
              "name": "number",
              "type": "AMAZON.NUMBER"
            }
          ],
          "samples": [
            "create appointment for {tutorName} starting on  {startDate} and ending on  {endDate} from {startTime} till {endTime} for {classCode} num {number}"
          ]
        },
        {
          "name": "GetDays",
          "slots": [
            {
              "name": "dayOne",
              "type": "AMAZON.DayOfWeek"
            },
            {
              "name": "dayTwo",
              "type": "AMAZON.DayOfWeek"
            },
            {
              "name": "dayThree",
              "type": "AMAZON.DayOfWeek"
            }
          ],
          "samples": [
            "on {dayOne} and {dayTwo} and {dayThree}"
          ]
        },
        {
          "name": "PostAppointment",
          "slots": [],
          "samples": [
            "create appointment"
          ]
        },
        {
          "name": "LaunchRequest"
        }
      ],
      "types": [
        {
          "name": "ClassCode",
          "values": [
            {
              "name": {
                "value": "CSC"
              }
            },
            {
              "name": {
                "value": "CIS"
              }
            },
            {
              "name": {
                "value": "MAT"
              }
            },
            {
              "name": {
                "value": "BIO"
              }
            }
          ]
        }
      ]
    },
    "dialog": {
      "intents": [
        {
          "name": "GetAppointment",
          "confirmationRequired": false,
          "prompts": {},
          "slots": [
            {
              "name": "tutorName",
              "type": "AMAZON.Person",
              "confirmationRequired": false,
              "elicitationRequired": true,
              "prompts": {
                "elicitation": "Elicit.Slot.572341544467.740424401845"
              }
            },
            {
              "name": "startDate",
              "type": "AMAZON.DATE",
              "confirmationRequired": false,
              "elicitationRequired": true,
              "prompts": {
                "elicitation": "Elicit.Slot.572341544467.802043734586"
              }
            },
            {
              "name": "endDate",
              "type": "AMAZON.DATE",
              "confirmationRequired": false,
              "elicitationRequired": true,
              "prompts": {
                "elicitation": "Elicit.Slot.572341544467.145226245668"
              }
            },
            {
              "name": "startTime",
              "type": "AMAZON.TIME",
              "confirmationRequired": false,
              "elicitationRequired": true,
              "prompts": {
                "elicitation": "Elicit.Slot.572341544467.1469916844436"
              }
            },
            {
              "name": "endTime",
              "type": "AMAZON.TIME",
              "confirmationRequired": false,
              "elicitationRequired": true,
              "prompts": {
                "elicitation": "Elicit.Slot.572341544467.1520196498315"
              }
            },
            {
              "name": "classCode",
              "type": "ClassCode",
              "confirmationRequired": false,
              "elicitationRequired": true,
              "prompts": {
                "elicitation": "Elicit.Slot.572341544467.358759548625"
              }
            },
            {
              "name": "number",
              "type": "AMAZON.NUMBER",
              "confirmationRequired": false,
              "elicitationRequired": false,
              "prompts": {}
            }
          ]
        }
      ],
      "delegationStrategy": "ALWAYS"
    },
    "prompts": [
      {
        "id": "Elicit.Slot.572341544467.740424401845",
        "variations": [
          {
            "type": "PlainText",
            "value": "I did not hear your name please restate"
          }
        ]
      },
      {
        "id": "Elicit.Slot.572341544467.802043734586",
        "variations": [
          {
            "type": "PlainText",
            "value": "I did not hear a starting date please restate"
          }
        ]
      },
      {
        "id": "Elicit.Slot.572341544467.145226245668",
        "variations": [
          {
            "type": "PlainText",
            "value": "I did not hear an ending date please restate"
          }
        ]
      },
      {
        "id": "Elicit.Slot.572341544467.1469916844436",
        "variations": [
          {
            "type": "PlainText",
            "value": "I did not hear a Sarting time for your session please restate"
          }
        ]
      },
      {
        "id": "Elicit.Slot.572341544467.1520196498315",
        "variations": [
          {
            "type": "PlainText",
            "value": "I did not hear an ending time for your session"
          }
        ]
      },
      {
        "id": "Elicit.Slot.572341544467.358759548625",
        "variations": [
          {
            "type": "PlainText",
            "value": "I did not hear the class code please restate"
          }
        ]
      }
    ]
  }
};

