const mongoose = require('mongoose');
const NoteSchema = new mongoose.Schema({  
  //apptId: mongoose.Schema.Types.ObjectId,
  classCode: String,
  startDate: String,
  endDate: String,
  startTime: String,
  endTime: String,
  tutorName: String,
  days: [String]
});
module.exports = mongoose.model('Note', NoteSchema);