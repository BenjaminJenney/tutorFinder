const mongoose = require('mongoose');

const RequestSchema = new mongoose.Schema({
    //requestId: mongoose.Schema.Types.ObjectId,
    classCode: String,
    startTime: String,
    endTime: String,
    studentsRequested: String,
    days: [String]
}, {timestamps: true} );

module.exports = mongoose.model('Request', RequestSchema);

