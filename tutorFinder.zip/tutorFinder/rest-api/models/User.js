const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    userName: String,
    isAdmin: Boolean,
    password: String
});

module.exports = mongoose.model('User', UserSchema);