require('dotenv').config({ path: './variables.env' });

const connectToDatabase = require('./db');
const Request = require('./models/Request');
//const request = require('./request')


module.exports.createRequest = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;

  connectToDatabase()
    .then(() => {
      Request.create(JSON.parse(event.body))
        .then(request => 
          callback(null, {
          statusCode: 200,
          body: JSON.stringify(request)
        }))
        .catch(err => callback(null, {
          statusCode: err.statusCode || 500,
          headers: { 'Content-Type': 'text/plain' },
          body: 'Could not create the request.'
        }));
      });
};

module.exports.getOneRequest = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;

  connectToDatabase()
    .then(() => {
      Request.findById(event.pathParameters.id)
        .then(request => callback(null, {
          statusCode: 200,
          body: JSON.stringify(request)
        }))
        .catch(err => callback(null, {
          statusCode: err.statusCode || 500,
          headers: { 'Content-Type': 'text/plain' },
          body: 'Could not fetch the request.'
        }));
    });
};

module.exports.getAllRequests = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;

  connectToDatabase()
    .then(() => {
      Request.find()
        .then(requests => callback(null, {
          statusCode: 200,
          body: JSON.stringify(requests)
        }))
        .catch(err => callback(null, {
          statusCode: err.statusCode || 500,
          headers: { 'Content-Type': 'text/plain' },
          body: 'Could not fetch the requests.'
        }))
    });
};

module.exports.updateRequest = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;

  connectToDatabase()
    .then(() => {
      Request.findByIdAndUpdate(event.pathParameters.id, JSON.parse(event.body), { new: true })
        .then(request => callback(null, {
          statusCode: 200,
          body: JSON.stringify(request)
        }))
        .catch(err => callback(null, {
          statusCode: err.statusCode || 500,
          headers: { 'Content-Type': 'text/plain' },
          body: 'Could not fetch the requests.'
        }));
    });
};

module.exports.deleteRequest = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;

  connectToDatabase()
    .then(() => {
      Request.findByIdAndRemove(event.pathParameters.id)
        .then(request => callback(null, {
          statusCode: 200,
          body: JSON.stringify({ message: 'Removed request with id: ' + request._id, request: request })
        }))
        .catch(err => callback(null, {
          statusCode: err.statusCode || 500,
          headers: { 'Content-Type': 'text/plain' },
          body: 'Could not fetch the requests.'
        }));
    });
};

